package databasePart1;

public class HW2 {

}
