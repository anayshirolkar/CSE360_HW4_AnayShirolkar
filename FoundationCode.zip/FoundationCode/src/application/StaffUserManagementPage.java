// StaffUserManagementPage.java
package application;

import javafx.collections.FXCollections;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.util.List;
import java.util.stream.Collectors;

public class StaffUserManagementPage {
    public void show(Stage primaryStage) {
        VBox layout = new VBox(10);

        TextField searchField = new TextField();
        searchField.setPromptText("Search by username or email");

        Button searchButton = new Button("Search");
        Button viewSuspendedButton = new Button("View Suspended Users");
        ListView<String> userList = new ListView<>();

        searchButton.setOnAction(e -> {
            String query = searchField.getText().trim().toLowerCase();
            List<String> results = User.getAllUsers().stream()
                .filter(u -> u.getUserName().toLowerCase().contains(query) ||
                             u.getEmail().toLowerCase().contains(query))
                .map(u -> u.getUserName() + " (" + u.getEmail() + ")")
                .collect(Collectors.toList());
            userList.setItems(FXCollections.observableArrayList(results));
        });

        viewSuspendedButton.setOnAction(e -> {
            List<String> suspended = User.getAllUsers().stream()
                .filter(User::isSuspended)
                .map(User::getUserName)
                .collect(Collectors.toList());
            userList.setItems(FXCollections.observableArrayList(suspended));
        });

        layout.getChildren().addAll(new Label("User Management"), searchField, searchButton,
            viewSuspendedButton, new Label("Results:"), userList);
        primaryStage.setScene(new Scene(layout, 600, 400));
        primaryStage.setTitle("User Management");
        primaryStage.show();
    }
}
