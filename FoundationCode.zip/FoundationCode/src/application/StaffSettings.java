package application;

public class StaffSettings {

	public static String getBroadcastMessage() {
		// TODO Auto-generated method stub
		return null;
	}

}
