// StaffSettings.java
package application;

public class StaffSetting {
    private static boolean reviewerRequestsEnabled = true;
    private static String broadcastMessage = "";

    public static boolean isReviewerRequestsEnabled() {
        return reviewerRequestsEnabled;
    }

    public static void setReviewerRequestsEnabled(boolean enabled) {
        reviewerRequestsEnabled = enabled;
    }

    public static String getBroadcastMessage() {
        return broadcastMessage;
    }

    public static void setBroadcastMessage(String message) {
        broadcastMessage = message;
    }
}