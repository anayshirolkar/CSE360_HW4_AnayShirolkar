package application;

import databasePart1.DatabaseHelper;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class WelcomeLoginPage {
    public WelcomeLoginPage(DatabaseHelper databaseHelper) {
		// TODO Auto-generated constructor stub
	}

	public void show(Stage primaryStage, User user) {
        String broadcast = StaffSettings.getBroadcastMessage();
        if (broadcast == null || broadcast.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Announcement");
            alert.setHeaderText("Message from Staff");
            alert.setContentText(broadcast);
            alert.showAndWait();
        }

        VBox layout = new VBox(20);
        layout.setStyle("-fx-padding: 30; -fx-alignment: center;");
        Label welcome = new Label("Welcome to the Learning Platform!");

        Button proceedButton = new Button("Continue");
        proceedButton.setOnAction(e -> {
            SetupLoginSelectionPage selectionPage = new SetupLoginSelectionPage(null);
            selectionPage.show(primaryStage);
        });

        layout.getChildren().addAll(welcome, proceedButton);
        Scene scene = new Scene(layout, 600, 400);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Welcome");
        primaryStage.show();
    }
}