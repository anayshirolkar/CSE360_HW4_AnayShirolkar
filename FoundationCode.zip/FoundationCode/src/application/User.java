package application;

import java.util.ArrayList; import java.util.List;

public class User { private String userName; private String email; private String password; private boolean suspended = false; private String role;

public static List<User> allUsers = new ArrayList<>(); // For search/suspend/reset

public User(String userName, String email, String password) {
    this.userName = userName;
    this.email = email;
    this.setPassword(password);
    allUsers.add(this);
}

public String getUserName() {
    return userName;
}

public String getEmail() {
    return email;
}

public void suspendUser() {
    this.suspended = true;
}

public boolean isSuspended() {
    return suspended;
}

public void resetPassword() {
    this.setPassword("Temp123!");
}

public static List<User> getAllUsers() {
    return allUsers;
}

@Override
public String toString() {
    return userName + " (" + email + ")";
}

public String getRole() {
    return role;
}

public void setRole(String role) {
    this.role = role;
}

public String getPassword() {
    return password;
}

public void setPassword(String password) {
    this.password = password;
}

}