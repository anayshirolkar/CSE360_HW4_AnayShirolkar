package application;

import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class StaffPlatformSettingsPage {
    public void show(Stage primaryStage) {
        VBox layout = new VBox(10);

        CheckBox toggleReviewerRequests = new CheckBox("Allow Reviewer Requests");
        toggleReviewerRequests.setSelected(StaffSetting.isReviewerRequestsEnabled());

        TextArea announcementField = new TextArea();
        announcementField.setPromptText("Broadcast message (shown to all users on login)");
        announcementField.setText(StaffSetting.getBroadcastMessage());

        Button saveButton = new Button("Save Settings");
        saveButton.setOnAction(e -> {
            StaffSetting.setReviewerRequestsEnabled(toggleReviewerRequests.isSelected());
            StaffSetting.setBroadcastMessage(announcementField.getText());
        });

        layout.getChildren().addAll(new Label("Platform Settings"), toggleReviewerRequests,
            new Label("Broadcast Message:"), announcementField, saveButton);
        primaryStage.setScene(new Scene(layout, 600, 400));
        primaryStage.setTitle("Platform Settings");
        primaryStage.show();
    }
}
