package application;

import databasePart1.DatabaseHelper;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class AdminHomePage {
    public AdminHomePage(DatabaseHelper databaseHelper, String username) {
		// TODO Auto-generated constructor stub
	}

	public void show(Stage primaryStage) {
        VBox layout = new VBox(15);
        layout.setStyle("-fx-padding: 20; -fx-alignment: center;");

        Label title = new Label("Welcome, Admin!");

        Button manageUsersButton = new Button("Manage Users");
        manageUsersButton.setOnAction(e -> new StaffUserManagementPage().show(primaryStage));

        Button platformSettingsButton = new Button("Platform Settings");
        platformSettingsButton.setOnAction(e -> new StaffPlatformSettingsPage().show(primaryStage));

        layout.getChildren().addAll(title, manageUsersButton, platformSettingsButton);

        Scene scene = new Scene(layout, 600, 400);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Admin Dashboard");
        primaryStage.show();
    }
}
