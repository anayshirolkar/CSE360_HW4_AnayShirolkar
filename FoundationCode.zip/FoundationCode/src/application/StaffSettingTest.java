package application;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class StaffSettingTest {

    @BeforeEach
    public void setUp() {
        // Reset to default before each test
        StaffSetting.setReviewerRequestsEnabled(true);
        StaffSetting.setBroadcastMessage("");
    }

    @AfterEach
    public void tearDown() {
        // Clean up after each test (reset to default)
        StaffSetting.setReviewerRequestsEnabled(true);
        StaffSetting.setBroadcastMessage("");
    }

    @Test
    public void testReviewerRequestsEnabledSetterGetter() {
        StaffSetting.setReviewerRequestsEnabled(false);
        assertFalse(StaffSetting.isReviewerRequestsEnabled(), "Reviewer requests should be disabled");

        StaffSetting.setReviewerRequestsEnabled(true);
        assertTrue(StaffSetting.isReviewerRequestsEnabled(), "Reviewer requests should be enabled");
    }

    @Test
    public void testBroadcastMessageSetterGetter() {
        String message = "System maintenance at 10 PM";
        StaffSetting.setBroadcastMessage(message);
        assertEquals(message, StaffSetting.getBroadcastMessage(), "Broadcast message should match the set value");
    }

    @Test
    public void testBroadcastMessageEmptyByDefault() {
        assertEquals("", StaffSetting.getBroadcastMessage(), "Broadcast message should be empty by default");
    }
}
