module FoundationCode {
	requires javafx.controls;
	requires java.sql;
	requires org.junit.jupiter.api;
	requires junit;
	
	opens application to javafx.graphics, javafx.fxml;
}